---
image_path: /img/portfolio/3.jpg
category: Web Design
project_name: Pinterest
link: https://pinterest.com
---
